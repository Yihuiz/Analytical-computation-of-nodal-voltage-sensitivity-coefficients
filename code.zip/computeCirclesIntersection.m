function [C,D] = computeCirclesIntersection(A,B,R1,R2)
    C = zeros(1,2);
    D = zeros(1,2);
    
    d = sqrt((A(1)-B(1))^2 + (A(2)-B(2))^2);
    a = (R1^2-R2^2+d^2)/(2*d);
    h = sqrt(R1^2-a^2);
    x2 = A(1) + a*(B(1)-A(1))/d;   
    y2 = A(2) + a*(B(2)-A(2))/d;   
    C(1) = x2 + h*(B(2)-A(2))/d;       
    C(2) = y2 - h*(B(1)-A(1))/d;
    D(1) = x2 - h*(B(2)-A(2))/d;
    D(2) = y2 + h*(B(1)-A(1))/d;
end

