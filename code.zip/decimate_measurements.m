clear;

addpath(genpath('from_yihui'));

% Load simulation results
load('Results - OPF-UFLS\LoadBusPQFV.mat');
load('Results - OPF-UFLS\GeneratorPQFreq_Vmagphase.mat');
load('Results - OPF-UFLS\BusV_mag_phase.mat');

Gen2 = Gen;
Eastsys2 = Eastsys;
Northsys2 = Northsys;
Westsys2 = Westsys;
BusV2 = BusV;

clear Gen Eastsys Northsys Westsys BusV

Gen.time = Gen2.time(1:100:end);
Gen.P = Gen2.P(:,1:100:end);
Gen.Q = Gen2.Q(:,1:100:end);
Gen.freq = Gen2.freq(:,1:100:end);
Gen.V = Gen2.GenV_magnitude(:,1:100:end);
Gen.Th = Gen2.GenV_phase(:,1:100:end);
Gen.sequence = Gen2.sequence;

Eastsys.loadP = Eastsys2.loadP(:,1:100:end);
Eastsys.loadQ = Eastsys2.loadQ(:,1:100:end);
Eastsys.loadFreq = Eastsys2.loadFreq(:,1:100:end);
Eastsys.sequence = Eastsys2.sequence;

Northsys.loadP = Northsys2.loadP(:,1:100:end);
Northsys.loadQ = Northsys2.loadQ(:,1:100:end);
Northsys.loadFreq = Northsys2.loadFreq(:,1:100:end);
Northsys.sequence = Northsys2.sequence;

Westsys.loadP = Westsys2.loadP(:,1:100:end);
Westsys.loadQ = Westsys2.loadQ(:,1:100:end);
Westsys.loadFreq = Westsys2.loadFreq(:,1:100:end);
Westsys.sequence = Westsys2.sequence;

BusV.V = BusV2.magnitude(:,1:100:end);
BusV.Th = BusV2.phase(:,1:100:end);
BusV.sequence = BusV2.sequence;

clear Gen2 Eastsys2 Northsys2 Westsys2 BusV2
% save sim_results