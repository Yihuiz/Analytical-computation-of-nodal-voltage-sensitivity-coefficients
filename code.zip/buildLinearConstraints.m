function [cons] = buildLinearConstraints(vertices,idx,n,x,y)
    if idx < n
        if abs(vertices(idx,1)-vertices(idx+1,1)) < 1e-9 % Same abscissa => vertical segment
            if vertices(idx,1) > 0 % RHS
                cons = (x <= vertices(idx,1));
            else % LHS
                cons = (x >= vertices(idx,1));
            end
        else
            slope = (vertices(idx+1,2)-vertices(idx,2))/(vertices(idx+1,1)-vertices(idx,1));
            if vertices(idx+1,1) > vertices(idx,1) % y <= ax+b
                cons = (y <= slope*(x-vertices(idx,1)) + vertices(idx,2));
            else % y >= ax+b
                cons = (y >= slope*(x-vertices(idx,1)) + vertices(idx,2));
            end
        end
    else % Last segment
        slope = (vertices(1,2)-vertices(n,2))/(vertices(1,1)-vertices(n,1));
        cons = (y <= slope*(x-vertices(n,1)) + vertices(n,2));
    end
end

