function [Cp_V,Cq_V,Cv_V,Cp_I_com,Cq_I_com,Cv_I_com] = sensCoeffs_Polar(Y,YL,YT,V,Psp,Qsp,Vsp,kpv,kqv,sl,pv,pq,wrt_pq,wrt_pv,wrt_sl)
    % Remove slacks
    V_no_sl = V;
    V_no_sl(sl) = [];
    G = real(Y);
    B = imag(Y);
    Y_new = Y;
    Y_new(sl,:) = [];
    Y_new_no_sl = Y_new;
    Y_new_no_sl(:,sl) = [];
    G_new = real(Y_new);
    B_new = imag(Y_new);
    G_new_no_sl = real(Y_new_no_sl);
    B_new_no_sl = imag(Y_new_no_sl);
    
    nsl = length(sl);
    npv = length(pv);
    npq = length(pq);
    n = nsl+npv+npq;
    
    pv_pq = sort([pv;pq]);
    [~,pv_no_sl,~] = intersect(sort([pv;pq]),pv);
    [~,pq_no_sl,~] = intersect(sort([pv;pq]),pq);
    
    wrt_pq_save = wrt_pq;
    wrt_pq_p = sort([wrt_pq;wrt_pv]);
    [~,wrt_pq,idx_wrt_pq] = intersect(wrt_pq_p,wrt_pq);
    [~,wrt_pv,idx_wrt_pv] = intersect(wrt_pq_p,wrt_pv);
    
    wrt_v = sort([wrt_pv;wrt_sl]);
    [~,wrt_pv_v,idx_wrt_pv_v] = intersect(wrt_v,wrt_pv);
        
    %% Build system for P    
    A_RV_diag = zeros(n-nsl,npq);
    A_RT_diag = zeros(n-nsl,n-nsl);
    A_IV_diag = zeros(npq,npq);
    A_IT_diag = zeros(npq,n-nsl);
    
    % Diagonal terms - PQ nodes
    A_RV_diag(pq_no_sl,:) = diag(cos(angle(V(pq))).*(G(pq,:)*real(V)-B(pq,:)*imag(V))+...
                                 sin(angle(V(pq))).*(B(pq,:)*real(V)+G(pq,:)*imag(V))-...
                                 Psp(pq)./Vsp(pq).^kpv(pq).*kpv(pq).*abs(V(pq)).^(kpv(pq)-1));
    A_RT_diag = diag(-imag(V_no_sl).*(G_new*real(V)-B_new*imag(V))+...
                     real(V_no_sl).*(B_new*real(V)+G_new*imag(V)));
    A_IV_diag = diag(-cos(angle(V(pq))).*(B(pq,:)*real(V)+G(pq,:)*imag(V))+...
                     sin(angle(V(pq))).*(G(pq,:)*real(V)-B(pq,:)*imag(V))-...
                     Qsp(pq)./Vsp(pq).^kqv(pq).*kqv(pq).*abs(V(pq)).^(kqv(pq)-1));
    A_IT_diag(:,pq_no_sl) = diag(imag(V(pq)).*(B(pq,:)*real(V)+G(pq,:)*imag(V))+...
                                 real(V(pq)).*(G(pq,:)*real(V)-B(pq,:)*imag(V)));

         
                             
    % All terms
    A_RV = real(V_no_sl).*(G_new(:,pq).*cos(angle(V(pq)))'-B_new(:,pq).*sin(angle(V(pq)))')+...
           imag(V_no_sl).*(B_new(:,pq).*cos(angle(V(pq)))'+G_new(:,pq).*sin(angle(V(pq)))');
    A_RT = real(V_no_sl).*(-G_new_no_sl.*imag(V_no_sl)'-B_new_no_sl.*real(V_no_sl)')+...
           imag(V_no_sl).*(-B_new_no_sl.*imag(V_no_sl)'+G_new_no_sl.*real(V_no_sl)');
    A_IV = imag(V(pq)).*(G(pq,pq).*cos(angle(V(pq)))'-B(pq,pq).*sin(angle(V(pq)))')-...
           real(V(pq)).*(B(pq,pq).*cos(angle(V(pq)))'+G(pq,pq).*sin(angle(V(pq)))'); 
    A_IT = imag(V(pq)).*(-G(pq,pv_pq).*imag(V_no_sl)'-B(pq,pv_pq).*real(V_no_sl)')-...
           real(V(pq)).*(-B(pq,pv_pq).*imag(V_no_sl)'+G(pq,pv_pq).*real(V_no_sl)');



    A_RV = A_RV + A_RV_diag;
    A_RT = A_RT + A_RT_diag;
    A_IV = A_IV + A_IV_diag;
    A_IT = A_IT + A_IT_diag;
    
    A = [A_RV A_RT;
         A_IV A_IT];
    %% Solve for P
    B_R = zeros(n-nsl,length(wrt_pq_p));
    B_I = zeros(npq,length(wrt_pq_p));
    
    % PQ
    B_R_PQ = diag((abs(V(pq))./Vsp(pq)).^kpv(pq));
    B_R(pq_no_sl,wrt_pq) = B_R_PQ(:,idx_wrt_pq);
    
%    PV
    B_R_PV = eye(npv);
    B_R(pv_no_sl,wrt_pv) = B_R_PV(:,idx_wrt_pv);
%     
    RHS = [B_R;B_I];
    
    Cp_V_tmp = A\RHS;
   

    Cp_V = Cp_V_tmp(1:npq,:);
    Cp_T = Cp_V_tmp(npq+1:end,:);
    
    %% Solve for Q    
    [~,wrt_pq,idx_wrt_pq] = intersect(wrt_pq_save,pq);
    
    B_R = zeros(n-nsl,length(wrt_pq));
    B_I = zeros(npq,length(wrt_pq));
    
    % PQ
    B_I_PQ = diag((abs(V(pq))./Vsp(pq)).^kqv(pq));
    B_I(:,wrt_pq) = B_I_PQ(:,idx_wrt_pq);

% %     % PV add 2021013 
%     B_I_PV = eye(npv+1);
%     B_I(sort([sl;pv_no_sl]),wrt_pv) = B_I_PV(:,idx_wrt_pv);
%     
    RHS = [B_R;B_I];
    
    Cq_V_tmp = A\RHS;
    
%     Cq_V = Cq_V_tmp(1:npq,:);
   Cq_V = Cq_V_tmp(1:npq,:);
    Cq_T = Cq_V_tmp(npq+1:end,:);
    
    %% Solve for V
    B_R = zeros(n-nsl,length(wrt_v));
    B_I = zeros(npq,length(wrt_v));
    
    B_R_PV = -diag(cos(angle(V(pv))).*(G(pv,:)*real(V)-B(pv,:)*imag(V))+...
                   sin(angle(V(pv))).*(B(pv,:)*real(V)+G(pv,:)*imag(V)));
    B_R(pv_no_sl,wrt_pv_v) = B_R_PV(:,idx_wrt_pv_v);    
    
    
    B_R = B_R - (real(V_no_sl).*(G_new(:,wrt_v).*cos(angle(V(wrt_v)))'-B_new(:,wrt_v).*sin(angle(V(wrt_v)))')+...
                 imag(V_no_sl).*(B_new(:,wrt_v).*cos(angle(V(wrt_v)))'+G_new(:,wrt_v).*sin(angle(V(wrt_v)))'));
    B_I = B_I - (imag(V(pq)).*(G(pq,wrt_v).*cos(angle(V(wrt_v)))'-B(pq,wrt_v).*sin(angle(V(wrt_v)))')-...
                 real(V(pq)).*(B(pq,wrt_v).*cos(angle(V(wrt_v)))'+G(pq,wrt_v).*sin(angle(V(wrt_v)))')); 
    

    RHS = [B_R;B_I];
    
    Cv_V_tmp = A\RHS;
    
    Cv_V = Cv_V_tmp(1:npq,:);
    Cv_T = Cv_V_tmp(npq+1:end,:);
    
     %% Currents sensitivity coefficients
    Cp_I_com = zeros(n,n,length(wrt_pq_p));
    Cq_I_com = zeros(n,n,length(wrt_pq));
    Cv_I_com = zeros(n,n,length(wrt_v));
    
    % Add slacks
    Cp_V_tmp = zeros(n,length(wrt_pq_p));
    Cp_T_tmp = zeros(n,length(wrt_pq_p));
    Cp_V_tmp(pq,:) = Cp_V;
    Cp_T_tmp(sort([pv;pq]),:) = Cp_T;
    Cp_V_com = V./abs(V).*Cp_V_tmp + 1j*V.*Cp_T_tmp;
    
    Cq_V_tmp = zeros(n,length(wrt_pq));
    Cq_T_tmp = zeros(n,length(wrt_pq));
    Cq_V_tmp(pq,:) = Cq_V;
    Cq_T_tmp(sort([pv;pq]),:) = Cq_T;
    Cq_V_com = V./abs(V).*Cq_V_tmp + 1j*V.*Cq_T_tmp;
    
    Cv_V_tmp = zeros(n,length(wrt_v));
    Cv_T_tmp = zeros(n,length(wrt_v));
    Cv_V_tmp(pq,:) = Cv_V;
    Cv_T_tmp(sort([pv;pq]),:) = Cv_T;
    Cv_V_tmp(sort([sl;pv]),:) = eye([nsl+npv length(wrt_v)]);
    Cv_V_com = V./abs(V).*Cv_V_tmp + 1j*V.*Cv_T_tmp;
    
    for k = 1:length(wrt_pq_p)
        Cp_I_com(:,:,k) = diag(Cp_V_com(:,k))*YL;
        Cp_I_com(:,:,k) = Cp_I_com(:,:,k) - Cp_I_com(:,:,k).' + diag(Cp_V_com(:,k))*YT; 
    end
    
    for k = 1:length(wrt_pq)
        Cq_I_com(:,:,k) = diag(Cq_V_com(:,k))*YL;
        Cq_I_com(:,:,k) = Cq_I_com(:,:,k) - Cq_I_com(:,:,k).' + diag(Cq_V_com(:,k))*YT;   
    end
    
    for k = 1:length(wrt_v)
        Cv_I_com(:,:,k) = diag(Cv_V_com(:,k))*YL;
        Cv_I_com(:,:,k) = Cv_I_com(:,:,k) - Cv_I_com(:,:,k).' + diag(Cv_V_com(:,k))*YT;  
    end
end