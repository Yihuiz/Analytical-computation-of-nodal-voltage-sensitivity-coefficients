
%%
% load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/Test Sensitivity Coefficients add load 16 100MW_10MVar/Load16-150/Eastsys.mat')
% load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/Test Sensitivity Coefficients add load 16 100MW_10MVar/Load16-150/Northsys.mat')
% load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/Test Sensitivity Coefficients add load 16 100MW_10MVar/Load16-150/Westsys.mat')
load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/ConfigII_NOUFLS/Eastsys.mat')
load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/ConfigII_NOUFLS/Northsys.mat')
load('/Users/zuo/Documents/PhD Papers/Conference/Powertech2021/OPF-UFLS-lowinertia39bus/ConfigII_6SG/Result/ConfigII_NOUFLS/Westsys.mat')
%%
% obtain damping coeffecient 
% form of the tranferfunction 
%               (-1/(2H)*s-1)
% -----------------------------------------------------
% s^3+D/(2H)s^2+(1/T_eq +D/((T_eq*2H)+1/(T_eq^2*Req*2H)s
% Active power of ssynchronous generation 
Pegen = [Westsystem([26 31],:);Eastsystem([2 31 36],:);Northsystem(32,:)];
Pegen(3,183581:end)=0; 
Qegen = [Westsystem([26 31]+1,:);Eastsystem([2 31 36]+1,:);Northsystem(32+1,:)];

% rotor speed of syn generator
wgen = [Westsystem([26 31]+2,:);Eastsystem([2 31 36]+2,:);Northsystem(32+2,:)];
wgen(3,:)=[];% remove the tripped generator G4

% Generator Power loss PG_loss = P_G4, as input of the transfer function
% Input_exp2_2=[zeros(1,183580-170000+1) Pegen(3,183580)*ones(1,length(183581:260*1e3))]; 
Input_exp2_2=[0*((ones(1,183579-180000+1))-1) Pegen(3,183580)*ones(1,length(183580:280*1e3))]; 

% mean rotor speed deviation (frequency deviation) of all the remaining generators 
% Output_exp2=(mean(wgen(:,177000:260*1e3)))-1;% delta_f as output

Output_exp2=(mean(wgen(:,180000:280*1e3)))-1;% delta_f as output


newdata2 = iddata(Output_exp2',[Input_exp2_2'],1e-3);

% set the poles and zeros number
np2=3;
nz2=2;

opt = tfestOptions('Display','on','SearchMethod','gna','InitialCondition','estimate')
opt.OutputOffset=mean(mean(wgen(:,177000:183580)))-1;
% transfer function estimation
tfsys1 = tfest(newdata2,np2,nz2,opt);

% check the response of the estimated transfer function
L=length(Input_exp2_2);

% tfsys2.Den(4)=0
%%
 df=lsim(tfsys1,[Input_exp2_2' ],0:1e-3:(100));
 figure 
plot(Westsystem(1,180000:280*1e3),50*(Output_exp2+1),'LineWidth',3,'DisplayName','Actual output')
hold on
plot(Westsystem(1,180000:280*1e3),50*(1+df+opt.OutputOffset),'LineWidth',3,'DisplayName','estimated tf output')
set(gca,'FontSize',36)
legend('True value','Predicated value')
xlim([179 260])
%%
%       -0.01946 s - 0.0004152
%   -----------------------------------
%   s^3 + 0.35 s^2 + 0.3316 s + 0.04467

%          -0.01736 s - 0.0003224
%   -------------------------------------
%   s^3 + 0.3191 s^2 + 0.3186 s + 0.04002
% 
%   -0.008997 s^2 - 0.01551 s - 0.0002614
%   -------------------------------------
%    s^3 + 0.2908 s^2 + 0.2962 s + 0.03126

%  -0.0088 s^2 - 0.01506 s - 0.0002262
%   ------------------------------------
%   s^3 + 0.308 s^2 + 0.2904 s + 0.03183
%   -0.0088 s^2 - 0.01484 s - 0.0002262
%   -------------------------------------
%   s^3 + 0.2931 s^2 + 0.2918 s + 0.03156
 