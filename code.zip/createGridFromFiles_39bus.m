function [sl,pv,pq,Psp,Qsp,Vsp,Pmax,Qmin,Qmax,Y,YL,YT,kpv,kqv,kpf,kqf,Sn,H,Rp,Vb,Vn] = createGridFromFiles_39bus(busdata,linedata,transdata,Sb,fn)
    %% Bus data
    % File format:
    %   1: Type: 1: slack, 2: PV, 3: PQ 4: PQ_windfarm
    %   2,3: Psp,Qsp: Specified active, reactive powers [p.u.]
    %   4: Vsp: Specified voltage profile [p.u.]
    %   5: Pmax: Max gen power [p.u.]
    %   6,7: Qmin,Qmax: Min, max reactive powers [p.u.]
    %   8,9: kpv,kqv: Pload = Psp(V/Vsp)^kpv, Qload = Qsp(V/Vsp)^kqv
    %   10,11: kpf,kqf: Pload = Psp(1+kpf*df), Qload = Qsp(1+kqf*df)  
    %   12: Sn: generators base powers
    %   13: H: generators inertias
    %   14: Rp: generators Droop constants
    %   15: Vn: bus nominal voltage [V]
    %   16: Vb: bus base voltage [V]
    
    type = busdata(:,2);
    Psp = busdata(:,3);
    Qsp = busdata(:,4);
    Vsp = busdata(:,5);
    Pmax = busdata(:,6);
    Qmin = busdata(:,7);
    Qmax = busdata(:,8);
    kpv = busdata(:,9);
    kqv = busdata(:,10);
    kpf = busdata(:,11);
    kqf = busdata(:,12);
    Sn = busdata(:,13);
    H = busdata(:,14);
    Rp = busdata(:,15);
    Vn = busdata(:,16);
    Vb = busdata(:,17);
    
    sl = find(type == 1);
    pv = find(type == 2);
    pq = find(type == 3);
    
    Sn = Sn(sort([sl;pv]));
    H = H(sort([sl;pv]));
    Rp = Rp(sort([sl;pv]));
    
    Vsp = Vsp.*Vn./Vb;
    
    %% Line data
    % File format:
    %   1,2: fromBus, toBus
    %   3: type: 1: line, 2: transformer
    %   4,5,6: r [p.u.], x [p.u.], b [p.u.]
    
    fromBus = linedata(:,1);
    toBus = linedata(:,2);
    type = linedata(:,3);
    r = linedata(:,4);
    x = linedata(:,5);
    b = linedata(:,6)/2;
    
    %% Transformers
    % File format:
    %   1,2: fromBus, toBus
    %   3,4: R1 [Ohm], L1 [H]: primary winding
    %   5,6: R2 [Ohm], L2 [H]: secondary winding
    %   7,8: Rm [Ohm], Lm [H]: magnetizing core
    %   9,10: Vb1 [V], Vb2[V]: primary and secondary base voltages
    
    R1 = transdata(:,3);
    L1 = transdata(:,4);
    R2 = transdata(:,5);
    L2 = transdata(:,6);
    Rm = transdata(:,7);
    Lm = transdata(:,8);
    Vb1 = transdata(:,9);
    Vb2 = transdata(:,10);

%     Zb1 = 3*Vb1.^2/Sb; % Primary side is Delta-connected
%     Zb2 = Vb2.^2/Sb; % Secondary side is Wye-connected
    wn = 2*pi*fn;
    
%     r1 = R1./Zb1;
%     r2 = R2./Zb2;
%     rm = Rm./Zb1;
%     x1 = wn*L1./Zb1;
%     x2 = wn*L2./Zb2;
%     xm = wn*Lm./Zb1;

% input data is already in p.u. 
    r1 = R1;
    r2 = R2;
    rm = Rm;
    x1 = L1;
    x2 = L2;
    xm = Lm;
    
    
    z1 = r1 + 1j*x1;
    z2 = r2 + 1j*x2;
    zm = rm.*1j.*xm./(rm+1j*xm);
    
    z_num = z1.*z2 + z1.*zm + z2.*zm;
    
    % Longitudinal impedance
    z_t = z_num./zm;
    r_t = max(0,real(z_t));
    x_t = imag(z_t);
    
    % Primary transversal admittance
    z1_t = z_num./z2;
    y1_t = 1./z1_t;
    g1_t = real(y1_t);
    b1_t = imag(y1_t);
    
    % Secondary transversal admittance
    z2_t = z_num./z1;
    y2_t = 1./z2_t;
    g2_t = real(y2_t);
    b2_t = imag(y2_t);
    
    g = zeros(length(r),1);
    r(type == 2) = r_t;
    x(type == 2) = x_t;
    g(type == 2) = 0*g1_t;
    b(type == 2) = 0*b1_t;
    
    %% Build admittance matrix
    [Y,YL,YT] = YMatrix(fromBus,toBus,r,x,g,b);
end

