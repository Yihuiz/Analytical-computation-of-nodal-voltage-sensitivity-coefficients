clear
load('Eastsys.mat')
load('Northsys.mat')
load('Westsys.mat')
%%  Frequency, active and reactive power of generator buses
Westsys.baseMVA=100;
Eastsys.baseMVA=100;
Northsys.baseMVA=100;

% West system G2, G3 (in this sequence)
Westsys.time=Westsystem(1,1:5:1500000);
Westsys.GenP=[Westsystem([26 31],1:5:1500000)*1000]; % active power
Westsys.GenQ=[Westsystem([26 31]+1,1:5:1500000)*1000]; % reactive power
Westsys.GenFreq=Westsystem([26 31]+2,1:5:1500000)*50; % frequency in Hz
Westsys.GenV_magnitude=Westsystem([26 31]+3,1:5:1500000)*sqrt(3);% generator bus voltage
Westsys.GenV_phase=Westsystem([26 31]+4,1:5:1500000); % generator bus phases


% East system G4, G6, G7 (in this sequence)
Eastsys.time=Eastsystem(1,1:5:1500000);
Eastsys.GenP=[Eastsystem([2],1:5:1500000)*1000;Eastsystem([31 36],1:5:1500000)*1000];
Eastsys.GenQ=[Eastsystem([2+1],1:5:1500000)*1000;Eastsystem([31 36]+1,1:5:1500000)*1000];
Eastsys.GenFreq=Eastsystem([2 31 36]+2,1:5:1500000)*50;
Eastsys.GenV_magnitude=Eastsystem([2 31 36]+3,1:5:1500000)*sqrt(3);
Eastsys.GenV_phase=Eastsystem([2 31 36]+4,1:5:1500000);

% North system G10 (in this sequence)
Northsys.time=Northsystem(1,1:5:1500000);
Northsys.GenP=Northsystem([32],1:5:1500000)*1000;
Northsys.GenQ=Northsystem([ 32]+1,1:5:1500000)*1000;
Northsys.GenFreq=Northsystem([32]+2,1:5:1500000)*50; 
Northsys.GenV_magnitude=Northsystem([32]+3,1:5:1500000)*sqrt(3);
Northsys.GenV_phase=Northsystem([32]+4,1:5:1500000);

%%
% All Generators frequenc P, Q in sequence
% Gen.baseMVA=100; % power base 100 MVA
% Gen.Nominal_Volt=22e3;
% % Gen.Nominal_Volt=345e3;
% Gen.phase_unit='rad';
Gen.time=Westsys.time;

Gen.P=[Westsys.GenP;Eastsys.GenP;Northsys.GenP];
Gen.Q=[Westsys.GenQ;Eastsys.GenQ;Northsys.GenQ];
Gen.freq=[Westsys.GenFreq;Eastsys.GenFreq;Northsys.GenFreq];
Gen.V=[Westsys.GenV_magnitude;Eastsys.GenV_magnitude;Northsys.GenV_magnitude];
Gen.Th=[Westsys.GenV_phase;Eastsys.GenV_phase;Northsys.GenV_phase];

Gen.sequence={'G2' 'G3' 'G4' 'G6' 'G7' 'G10'};
%%
Gen.time = Gen.time(1:10:end);
Gen.P = Gen.P(:,1:10:end);
Gen.Q = Gen.Q(:,1:10:end);
Gen.freq = Gen.freq(:,1:10:end);
Gen.V = Gen.V(:,1:10:end);
Gen.Th = Gen.Th(:,1:10:end);
%% Frequency,active, reactive power of load buses 
clear Eastsys Westsys Northsys
% % West system Load 40, 4, 8, 39, 7, 12 31(in this sequence)
% Westsys.baseMVA=100;
% Westsys.Nominal_Volt=345e3;
% Westsys.phase_unit='rad';
Westsys.time=Westsystem(1,1:50:1500000);
Westsys.loadP=Westsystem([2 7 12 17 36 41 46],1:50:1500000)*1e-6; % active power
Westsys.loadQ=Westsystem([2 7 12 17 36 41 46]+1,1:50:1500000)*1e-6; % reactive power
Westsys.loadFreq=Westsystem([2 7 12 17 36 41 46]+2,1:50:1500000);  % frequency in Hz
% Westsys.loadV_magnitude=Westsystem([5 9 13 23 27 31]+3,:)*sqrt(3); % voltage magnitude
% Westsys.loadV_phase=Westsystem([5 9 13 23 27 31]+3,:); % voltage phase
Westsys.sequence=[40, 4, 8, 39, 7, 12, 31];

% East system Load 34, 15, 16, 20, 21, 23, 24 (in this sequence)

% Eastsys.baseMVA=100;
% Eastsys.Nominal_Volt=345e3;
% Eastsys.phase_unit='rad';
Eastsys.time=Eastsystem(1,1:50:1500000);
Eastsys.loadP=Eastsystem([7 12 17 22 41 46 51],1:50:1500000)*1e-6; % active power
Eastsys.loadQ=Eastsystem([7 12 17 22 41 46 51]+1,1:50:1500000)*1e-6; % reactive power
Eastsys.loadFreq=Eastsystem([7 12 17 22 41 46 51]+2,1:50:1500000);  % frequency in Hz
% Eastsys.loadV=Eastsystem([8 12 16 26 30 34]+3,:)*sqrt(3); % voltage
Eastsys.sequence=[34, 15, 16, 20, 21, 23, 24];

% North sysem load 37, 38, 25, 26, 28, 29, 3, 18, 27 (in this sequence)
% Northsys.baseMVA=100;
% Northsys.Nominal_Volt=345e3;
% Northtsys.phase_unit='rad';
Northsys.time=Northsystem(1,1:50:1500000);
Northsys.loadP=Northsystem([2 7 12 17 22 27 37 42 47],1:50:1500000)*1e-6; % active power
Northsys.loadQ=Northsystem([2 7 12 17 22 27 37 42 47]+1,1:50:1500000)*1e-6; % reactive power
Northsys.loadFreq=Northsystem([2 7 12 17 22 27 37 42 47]+2,1:50:1500000);  % frequency in Hz
% Northsys.loadV=Northsystem([8 12 16 20 27 31 35]+3,:)*sqrt(3); % voltage
Northsys.sequence=[37, 38, 25, 26, 28, 29, 3, 18, 27];

%%  voltage magnitudes and phases of all the buses

% west system 4 8 39 5 9 7 12 6 10 11 13
WestbusVm=[ Westsystem([10 15 20 22 24 39 44 51 53 55 57],1:50:1500000)*sqrt(3)];% voltage magnitude
WestbusVp=[Westsystem([10 15 20 22 24 39 44 51 53 55 57]+1,1:50:1500000)];% voltage phase


%East system 15 16 20 14 19 21 23 24 22
EastbusVm=[Eastsystem([15 20 25 27 29 44 49 54 56],1:50:1500000)*sqrt(3)];% voltage magnitude
EastbusVp=Eastsystem([15 20 25 27 29 44 49 54 56]+1,1:50:1500000);% voltage phase

%North system 25 26 28 29 3 18 27 1 2 17
NorthbusVm=[Northsystem([15 20 25 30 40 45 50 52 54 56],1:50:1500000)*sqrt(3)];
NorthbusVp=Northsystem([15 20 25 30 40 45 50 52 54 56]+1,1:50:1500000);

bus40=[Westsystem([5],1:50:1500000)*sqrt(2); Westsystem([6],1:50:1500000)];% bus 40
bus34=[Eastsystem([10],1:50:1500000)*sqrt(2);Eastsystem([11],1:50:1500000) ];% bus 34
bus37_38=[Northsystem([5 10],1:50:1500000)*sqrt(2);Northsystem([5 10]+1,1:50:1500000)];% bus 37 38
% BusV.Nominal_Volt=345e3;
% BusV.phase_unit='rad';
BusV.time=Westsystem(1,1:50:1500000);
BusV.V=[NorthbusVm([8 9 5],:);WestbusVm([1 4 8 6 2 5 9 10 7 11],:);...
    EastbusVm([4 1 2],:);NorthbusVm([10 6],:);EastbusVm([5 3 6 9 7 8],:);NorthbusVm([1 2 7 3 4],:);bus34(1,:);bus37_38([1 2],:);WestbusVm([3],:);bus40(1,:)];
BusV.Th=[NorthbusVp([8 9 5],:);WestbusVp([1 4 8 6 2 5 9 10 7 11],:);...
    EastbusVp([4 1 2],:);NorthbusVp([10 6],:);EastbusVp([5 3 6 9 7 8],:);NorthbusVp([1 2 7 3 4],:);bus34(2,:);bus37_38([3 4],:);WestbusVp([3],:);bus40(2,:)];
BusV.sequence=[1:29 34 37 38 39 40];% voltage magnitude and phase for all the bus expect for generator buses 


%% get nodal active power and voltage (in p.u.) of generators and loads before and after contingency for power flow 

% generator active power
GenP_intandpost=[Gen.P(:,Gen.time==1.799994500000000e2) Gen.P(:,Gen.time==2.200005500000000e+02) ];

GenQ_intandpost=[Gen.Q(:,Gen.time==1.799994500000000e2) Gen.Q(:,Gen.time==2.200005500000000e+02) ];


GenVmag_intandpost=[Gen.GenV_magnitude(:,Gen.time==1.799994500000000e2) Gen.GenV_magnitude(:,Gen.time==2.200005500000000e+02) ]/22e3;
 
% load active and reactive power

LoadWestP=[Westsys.loadP(:,Westsys.time==1.799994500000000e2) Westsys.loadP(:,Westsys.time==2.200005500000000e+02) ];
LoadWestQ=[Westsys.loadQ(:,Westsys.time==1.799994500000000e2) Westsys.loadQ(:,Westsys.time==2.200005500000000e+02) ];

LoadEastP=[Eastsys.loadP(:,Eastsys.time==1.799994500000000e2) Eastsys.loadP(:,Eastsys.time==2.200005500000000e+02) ];
LoadEastQ=[Eastsys.loadQ(:,Eastsys.time==1.799994500000000e2) Eastsys.loadQ(:,Eastsys.time==2.200005500000000e+02) ];

LoadNorthP=[Northsys.loadP(:,Northsys.time==1.799994500000000e2) Northsys.loadP(:,Northsys.time==2.200005500000000e+02) ];
LoadNorthQ=[Northsys.loadQ(:,Northsys.time==1.799994500000000e2) Northsys.loadQ(:,Northsys.time==2.200005500000000e+02) ];


% compare with simulink powergui load flow result



%% reference phase and phase convert

Genphase_intandpost=[Gen.GenV_phase(:,Gen.time==1.799994500000000e2) Gen.GenV_phase(:,Gen.time==2.200005500000000e+02) ];

 
BusVmag_intandpost=[BusV.magnitude(:,BusV.time==1.799994500000000e2) BusV.magnitude(:,BusV.time==2.200005500000000e+02)]/345e3;

BusVphase_intandpost=[BusV.phase(:,BusV.time==1.799994500000000e2) BusV.phase(:,BusV.time==2.200005500000000e+02)];




