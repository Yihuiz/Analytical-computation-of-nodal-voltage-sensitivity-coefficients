clear

% Add paths to Yalmip and Gurobi installation folders
addpath(genpath('Yalmip installation folder'));
addpath(genpath('Gurobi installation folder'));

% Load files of line, bus and transformer data
linedata = xlsread('grid-parameters_new.xlsx','linedata','A2:F48');
busdata = xlsread('grid-parameters_new.xlsx','busdata','A2:U41');
transdata = xlsread('grid-parameters_new.xlsx','trans','A2:J14');

Sb = 100e6; % Grid base power
fn = 50; % Grid nominal frequency
%%
[sl,pv,pq,Psp,Qsp,Vsp,Pmax,Qmin,Qmax,Y,YL,YT,kpv,kqv,kpf,kqf,Sn,H,Rp,Vb,Vn] = ...
    createGridFromFiles_39bus(busdata,linedata,transdata,Sb,fn);
%%
nsl = length(sl);
npv = length(pv);
npq = length(pq);
n = nsl+npv+npq;

n_lines = size(linedata,1);

Pmax = Pmax(sort([sl;pv]));

% Simulation time and number of steps
t1 = 18350; % Index of initial time
t2 = 29000; % Index of final time
h = 0.01; % Integration step (optimal: 0.01)
N = round((t2-t1)); % Number of steps
t_sim = N*h;

% Create UFLS structure for UFLS optimization problem
UFLS.t1 = t1;
UFLS.t2 = t2;
UFLS.h = h;
UFLS.N = N;
UFLS.sl = sl;
UFLS.pv = pv;
UFLS.pq = pq;
UFLS.Psp = Psp;
UFLS.Qsp = Qsp;
UFLS.Vsp = Vsp;
UFLS.fn = fn;
UFLS.Vb = Vb;
UFLS.Vn =Vn;
UFLS.Sn = Sn; % Generators base power [MW]
UFLS.Sgrid = Sb/1e6; % Grid base power [MW]
UFLS.n_lines = n_lines;
UFLS.Y = Y;
UFLS.YL = YL;
UFLS.YT = YT;
UFLS.kpv = kpv;
UFLS.kqv = kqv;
UFLS.kpf = kpf;
UFLS.kqf = kqf;
UFLS.Rp = Rp;
UFLS.H = H; % sec
UFLS.D = 31.01; % From system transfer function identificaiton 
UFLS.T = 24.54; % From curve fitting, not used in this configuration 
UFLS.Pmax = Pmax;
UFLS.Qmin = Qmin;
UFLS.Qmax = Qmax;
UFLS.t_sim = t_sim; % Prediction horizon

clearvars -except UFLS