[A,B,C,D]=tf2ss([ 0 tfsys1.num],tfsys1.den);

%%
x=[0;0;0];
for k=1:L
    y(k)=(C*x + D*u(k));
    x = x+0.01*(A*x + B*u(k));
end