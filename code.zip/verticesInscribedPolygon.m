function [vertices] = verticesInscribedPolygon(R,n)
    alpha = 30*pi/180; % Angle wrt vertical line
    step = round(2*R/n,3,'significant'); % Step length along oblique line
    t = (step:step:n*step)';

    % Intersections of vertical line with circle
    A = [0, R];
    B = [0, -R];

    % Intersections of circle 1 (A,2R) and circle 2 (B,2R)
    [C,D] = computeCirclesIntersection(A,B,2*R,2*R);

    % Intersections with oblique line
    int_obl = [A(1)-t*sin(alpha), A(2)-t*cos(alpha)];

    % Intersections with vertical line
    slope_seg = (B(2)-int_obl(end,2))/(B(1)-int_obl(end,1));
    int_ver = [zeros(n,1), int_obl(:,2) - slope_seg*int_obl(:,1)];
    int_even = int_ver(2:2:end,:); % Even intersections only

    % Vertices of polygone (intersections with circle)
    slope_C = (int_even(:,2)-C(2))./(int_even(:,1)-C(1));
    slope_D = (int_even(:,2)-D(2))./(int_even(:,1)-D(1));

    a_RHS = 1+slope_C.^2;
    b_RHS = 2*slope_C.*int_even(:,2);
    c_RHS = int_even(:,2).^2-R^2;

    a_LHS = 1+slope_D.^2;
    b_LHS = 2*slope_D.*int_even(:,2);
    c_LHS = int_even(:,2).^2-R^2;

    x_RHS = (-b_RHS + sqrt(b_RHS.^2-4*a_RHS.*c_RHS))./(2*a_RHS);
    x_LHS = (-b_LHS - sqrt(b_LHS.^2-4*a_LHS.*c_LHS))./(2*a_LHS);

    y_RHS = slope_C.*x_RHS + int_even(:,2);
    y_LHS = slope_D.*x_LHS + int_even(:,2);

    x_LHS = flip(x_LHS);
    y_LHS = flip(y_LHS);

    vertices = [0,     R;
                x_RHS, y_RHS;
                x_LHS, y_LHS];

    vertices = unique(vertices,'rows','stable'); % Remove potential duplicate in (0,-R)
end

